import TeacherLayout from './BasicLayout';

export default TeacherLayout;
