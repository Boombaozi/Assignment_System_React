import StudentLayout from './BasicLayout';

export default StudentLayout;
