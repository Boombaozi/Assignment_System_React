import AddStudent from './AddStudent';

export default AddStudent;
