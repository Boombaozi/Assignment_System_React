import test from './UserManagement';

export default test;
