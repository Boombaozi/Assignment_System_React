import EditTeacher from './AddStudent';

export default EditTeacher;
