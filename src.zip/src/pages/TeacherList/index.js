import teacherList from './UserManagement';

export default teacherList;
