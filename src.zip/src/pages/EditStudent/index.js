import EditStudent from './AddStudent';

export default EditStudent;
