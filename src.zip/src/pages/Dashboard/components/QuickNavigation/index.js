import QuickNavigation from './QuickNavigation';

export default QuickNavigation;
