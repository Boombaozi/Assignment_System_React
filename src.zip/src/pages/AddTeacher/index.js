import AddStudent from './AddStudent';

export default AddTeacher;
