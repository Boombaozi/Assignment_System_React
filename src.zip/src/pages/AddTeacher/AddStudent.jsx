import React, { Component } from 'react';
import AddForm from './components/AddForm';

export default class AddTeacher extends Component {
  render() {
    return (
      <div>
        <AddForm />
      </div>
    );
  }
}
