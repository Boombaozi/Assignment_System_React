import AddCourse from './AddStudent';

export default AddCourse;
