import UserTable from './UserTable';

export default UserTable;
