import CourseList from './UserManagement';

export default CourseList;
