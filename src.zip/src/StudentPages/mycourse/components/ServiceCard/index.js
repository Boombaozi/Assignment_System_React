import ServiceCard from './ServiceCard';

export default ServiceCard;
