import React, { Component } from 'react';

import axios from 'axios';
import { Message, Form, Button, Input, Select, Radio, Checkbox, DatePicker, Switch, Upload } from '@alifd/next';
import store from '../../store';
import IceContainer from '@icedesign/container';

export default class test2 extends Component {
  constructor(props) {
    super(props);
    this.state = {};

  }

  render() {

    return (
      <div>

      </div>
    );
  }
}
